// Minimal script - highlight active nav based on URL
document.addEventListener('DOMContentLoaded', function(){
  var navs = document.querySelectorAll('.site-nav a');
  navs.forEach(function(a){
    if(location.pathname.endsWith(a.getAttribute('href')) || (location.pathname.endsWith('/') && a.getAttribute('href')==='index.html')){
      a.classList.add('active');
    }
  });
});
